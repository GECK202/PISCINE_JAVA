
public class Program {

    public static void main(String[] args) {
        Menu menu = new Menu(new TransactionsService(new UsersArrayList()));
        if (args.length == 1 && args[0].equals("--profile=dev"))
            menu.devMenu();
        else
            menu.productionMenu();
    }

    public static void printTrans(Transaction[] list) {
        for (int i = 0; i < list.length; i++)
            if (list[i] != null) {
                System.out.println(list[i].getSender().getName() + " " + list[i].getReceiver().getName() + " " +
                        list[i].getCategoty() + " " + list[i].getSum() + " " + list[i].getId());
            }
    }
}