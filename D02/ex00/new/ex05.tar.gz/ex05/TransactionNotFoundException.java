

public class TransactionNotFoundException extends Exception {

}
