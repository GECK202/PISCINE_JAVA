
public interface UsersList {

    User getUserById(int id) throws UserNotFoundException; 
    User getUserByIndex(int i);
    void addUser(User u);
}