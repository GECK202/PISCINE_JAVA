
import java.util.UUID;

public class Transaction {
    private UUID id;
    private User sender; 
    private User receiver;
    private String category;
    private int sum;
    public Transaction next;

    public Transaction(User sender, User receiver, String category, int sum) {
        this.id = UUID.randomUUID();
        this.sender = sender;
        this.receiver = receiver;
        this.category = category;
        this.sum = sum;
    }

    public Transaction(UUID id, User sender, User receiver, String category, int sum) {
        this.id = id;
        this.sender = sender;
        this.receiver = receiver;
        this.category = category;
        this.sum = sum;
    }

    public UUID getId() {
        return this.id;
    }

    public User getSender() {
        return this.sender;
    }

    public User getReceiver() {
        return this.receiver;
    }

    public String getCategoty() {
        return this.category;
    }

    public int getSum() {
        return this.sum;
    }

    public UUID getNext() {
        if (this.next != null)
            return this.next.getId();
        return null;
    }
    
}