
import java.util.UUID;

public interface TransactionsList {
    
    void addTransaction(Transaction newTran);
    void delTransaction(UUID id) throws TransactionNotFoundException;
    Transaction[] listToArray();
}