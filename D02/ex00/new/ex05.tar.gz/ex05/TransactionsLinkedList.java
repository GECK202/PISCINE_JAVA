
import java.util.UUID;

public class TransactionsLinkedList implements TransactionsList {

    private Transaction head;

    @Override
    public void addTransaction(Transaction newTran) {
        if (head == null)
            head = newTran;
        else {
            Transaction tmp = head;
            head = newTran;
            head.next = tmp;
        }
    }

    @Override
    public void delTransaction(UUID id) throws TransactionNotFoundException {
        Transaction tmp = head;
        Transaction prev = null;
        while (tmp != null) {
            if (tmp.getId().equals(id)) {
                if (head.getId().equals(id)) {
                    head = head.next;
                    return;
                }
                if (prev != null)
                    prev.next = tmp.next;
                return;
            }
            prev = tmp;
            tmp = tmp.next;
        }
        throw new TransactionNotFoundException();
    }

    @Override
    public Transaction[] listToArray() {
        Transaction s = head;
        int count = 0;
        while (s != null) {
            count++;
            s = s.next;
        }
        Transaction[] arr = new Transaction[count];
        s = head;
        for (int i = 0; i < count; i++) {
            arr[i] = s;
            s =s.next;
        }
        return arr;
    }
}