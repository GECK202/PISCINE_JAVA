

public class IllegalTransactionException extends Exception {

}
