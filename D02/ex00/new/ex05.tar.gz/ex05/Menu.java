import java.util.Scanner;

public class Menu {

    private TransactionsService transactionsService;
    private Scanner scanner;

    public Menu(TransactionsService transactionsService) {
        this.transactionsService = transactionsService;
        this.scanner = new Scanner(System.in);
    }

    public void productionMenu() {
        String str = "";
        while (true) {
            printMenu();
            printMenuExit();
            str = scanner.nextLine();
            if (str.equals("1"))
                addUserCommand();
            else if (str.equals("2"))
                checkBallanceCommand();
            else if (str.equals("3"))
                remittanceCommand();
            else if (str.equals("4"))
                checkRemittancesCommand();
            else if (str.equals("7"))
                break;
            else
                System.out.println("Неверная команда");
        }
        scanner.close();
    }

    public void devMenu() {
        String str = "";
        while (true) {
            printDevMenu();
            printMenuExit();
            str = scanner.nextLine();
            if (str.equals("1"))
                addUserCommand();
            else if (str.equals("2"))
                checkBallanceCommand();
            else if (str.equals("3"))
                remittanceCommand();
            else if (str.equals("4"))
                checkRemittancesCommand();
            else if (str.equals("5"))
                deleteTransaction();
            else if (str.equals("6"))
                checkCorrectTransactions();
            else if (str.equals("7"))
                break;
            else
                System.out.println("Неверная команда");
        }
        scanner.close();
    }

    private void printMenu() {
        System.out.print("1. Добавить пользователя\n" + "2. Посмотреть баланс пользователей\n"
                + "3. Осуществить перевод\n" + "4. Посмотреть все переводы конкретного пользователя\n");
    }

    private void printDevMenu() {
        printMenu();
        System.out.print("5. DEV - удалить перевод по ID\n" + "6. DEV - проверить корректность переводов\n");
    }

    private void printMenuExit() {
        System.out.println("7. Завершить выполнение");
    }

    private int readInt(String text) {
        int i = -1;
        while (i < 0) {
            if (this.scanner.hasNextInt()) {
                i = this.scanner.nextInt();
                scanner.nextLine();
            } else {
                System.out.println(text);
                scanner.nextLine();
            }
        }
        return i;
    }

    private void addUserCommand() {
        System.out.println("Введите имя и баланс пользователя");
        String name = null;
        name = this.scanner.nextLine();
        int balance = readInt("Введите корректный баланс");
        User u = new User(name, balance);
        this.transactionsService.addUser(u);
        System.out.format("Пользователь добавлен с id = %d\n", u.getId());
    }

    private void checkBallanceCommand() {
        System.out.println("Введите id пользователя");
        int id = readInt("Введите корректный ID");
        try {
            System.out.format("%s - %d\n", this.transactionsService.getUser(id).getName(),
                    this.transactionsService.getBalance(id));
        } catch (UserNotFoundException e) {
            System.out.println("Пользователь с таким ID не найдет");
        }
    }

    private void remittanceCommand() {
        System.out.println("Введите id-отправителя, id-получается и сумму перевода");
        int idFrom = readInt("Введите корректный ID");
        int currBalance = 0;
        try {
            currBalance = this.transactionsService.getUser(idFrom).getBalance();
        } catch (UserNotFoundException e1) {
            System.out.println("Пользователь с таким ID не найдет");
        }
        int idTo = readInt("Введите корректный ID");
        int sum = readInt("Введите корректную сумму");
        while (sum > currBalance) {
            System.out.println("Введенная сумма превышает баланс");
            sum = readInt("Введите корректную сумму");
        }
        try {
            this.transactionsService.sendTransaction(idFrom, idTo, sum);
            System.out.println("Перевод осуществлен");
        } catch (UserNotFoundException e) {
            System.out.println("Пользователь с таким ID не найдет");
        }
    }

    private void checkRemittancesCommand() {
        System.out.println("Введите id пользователя");
        int id = readInt("Введите корректный ID");
        Transaction[] tarray = null;
        try {
            tarray = this.transactionsService.getTransactions(id);
            for (int i = 0; i < tarray.length; i++) {
                System.out.format("To %s(id = %d) %d with id = %s\n", tarray[i].getReceiver().getName(),
                        tarray[i].getReceiver().getId(), tarray[i].getSum(), tarray[i].getId());
            }
        } catch (UserNotFoundException e) {
            System.out.println("Пользователь с таким ID не найдет");
        }
    }

    private void deleteTransaction() {
        System.out.println("Введите id пользователя и id перевода");
        int idUser = readInt("Введите корректный ID");
        String idTran = scanner.nextLine();
        Transaction[] tarray = null;
        try {
            tarray = this.transactionsService.getUser(idUser).getTransactions().listToArray();
            for (int i = 0; i < tarray.length; i++) {
                if (tarray[i].getId().toString().equals(idTran))
                    this.transactionsService.delTransaction(idUser, tarray[i].getId());
                else
                    System.out.format("%s si not equal %s", tarray[i].getId().toString(), idTran);
            }
        } catch (UserNotFoundException e) {
            System.out.println("Пользователь с таким ID не найдет");
        } catch (TransactionNotFoundException e) {
            System.out.println("Транзакция не найдена");
        }
    }

    private void checkCorrectTransactions() {
        System.out.println("Результаты проверки:");
        Transaction[] arr = this.transactionsService.notCorrectTransactions();
        if (arr == null)
            return;
        for (int i = 0; i < arr.length; i ++) {
            if (arr[i] != null) {
                if (arr[i].getCategoty().equals("INCOME")) {
                    System.out.format("%s(id = %d) имеет неподтвержденный перевод id =\n", arr[i].getReceiver().getName(), arr[i].getReceiver().getId());
                    System.out.format("%s от %s(id = %d) на сумму %d\n", arr[i].getId().toString(), arr[i].getSender().getName(), 
                                        arr[i].getSender().getId(), arr[i].getSum());
                }
                else {
                    System.out.format("%s(id = %d) имеет неподтвержденный перевод id =\n", arr[i].getSender().getName(), arr[i].getSender().getId());
                    System.out.format("%s для %s(id = %d) на сумму %d\n", arr[i].getId().toString(), arr[i].getReceiver().getName(), 
                                        arr[i].getReceiver().getId(), arr[i].getSum());
                }
            }
        }
    }
}