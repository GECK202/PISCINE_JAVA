
import java.util.UUID;

public class TransactionsService {

    private UsersList usersList;

    public TransactionsService(UsersList usersArrayList) {
        this.usersList = usersArrayList;
    }

    public void addUser(User u) {
        this.usersList.addUser(u);
    }

    public User getUser(int id) throws UserNotFoundException {
        return this.usersList.getUserById(id);
    }

    public int getBalance(int id) throws UserNotFoundException {
        return this.usersList.getUserById(id).getBalance();
    }

    public void sendTransaction(int idFrom, int idTo, int sum) throws UserNotFoundException {
        User sender = this.usersList.getUserById(idFrom);
        User receiver = this.usersList.getUserById(idTo);
        if (sender == null || receiver == null)
            return;
        if (sender.getBalance() < sum) {
            try {
                throw new IllegalTransactionException();
            } catch (IllegalTransactionException e) {
                e.printStackTrace();
            }
        }
        Transaction tranTo = new Transaction(sender, receiver, "OUTCOME", sum * -1);
        Transaction tranFrom = new Transaction(tranTo.getId(), sender, receiver, "INCOME", sum);
        sender.setBalancse(sender.getBalance() - sum);
        receiver.setBalancse(receiver.getBalance() + sum);
        sender.addTransaction(tranTo);
        receiver.addTransaction(tranFrom);
    }


    public Transaction[] getTransactions(int id) throws UserNotFoundException {
        return this.usersList.getUserById(id).getTransactions().listToArray();
    }


    public void delTransaction(int idUser, UUID idTran) throws UserNotFoundException, TransactionNotFoundException {
        this.usersList.getUserById(idUser).getTransactions().delTransaction(idTran);
    }


    public Transaction[] notCorrectTransactions() {
        Transaction[] res = usersList.getUserByIndex(0).getTransactions().listToArray();
        Transaction[] tmp;
        int i = 1;
        while (usersList.getUserByIndex(i) != null) {
            tmp = usersList.getUserByIndex(i).getTransactions().listToArray();
            for (int j = 0; j < tmp.length; j++) {
                if (res.length == 0) {
                    res = updateTranArray(res, tmp[j]);
                    continue;
                }
                for (int z = 0; z < res.length; z++) {
                    if (res[z] != null) {
                        if (res[z].getId().toString().equals(tmp[j].getId().toString())) {
                            res[z] = null;
                            break;
                        } else {
                            if (!containsIt(res, tmp[j])) {
                                res = updateTranArray(res, tmp[j]);
                                break;
                            }
                        }
                    }
                }
            }
            i++;
        }
        return res;
    }

    private boolean containsIt(Transaction[] list, Transaction tran) {
        for (int i = 0; i < list.length; i++) {
            if (list[i] != null && list[i].getId().toString().equals(tran.getId().toString()))
                return true;
        }
        return false;
    }

    private Transaction[] updateTranArray(Transaction[] arr, Transaction tran) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == null) {
                arr[i] = tran;
                return arr;
            }
        }
        Transaction[] newArr = new Transaction[arr.length + 5];
        int i = 0;
        while (i < arr.length) {
            newArr[i] = arr[i];
            i++;
        }
        newArr[i] = tran;
        return newArr;
    }
}