

public class UserNotFoundException extends Exception {

}
