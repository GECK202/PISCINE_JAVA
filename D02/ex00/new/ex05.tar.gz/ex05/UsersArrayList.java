
public class UsersArrayList implements UsersList {

    private User[] list = new User[10];

    @Override
    public User getUserById(int id) throws UserNotFoundException {
        User user = null;

        for (User u : list)
            if (u != null && u.getId() == id) {
                user = u;
                return u;
            }

        throw new UserNotFoundException();
    }

    public User getUserByIndex(int i) {
        if (i < list.length)
            return list[i];
        return null;
    }

    @Override
    public void addUser(User u) {
        if (findLast() == list.length) {
            User[] tmp = new User[(int)(list.length * 1.5)];
            for (int i = 0; i < list.length; i ++)
                tmp[i] = list[i];
            list = tmp;
            tmp = null;
        }
        int i = findLast();
        list[i] = u;
    }

    private int findLast() {
        int i = 0;
        while (i < list.length) {
            if (list[i] == null)
                return i;
            i++;
        }
        return i;
    }
}