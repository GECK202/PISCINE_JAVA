
public class User {
    private int id;
    private String name;
    private int balance;
    private TransactionsList transactionsList;

    public User(String name, int balance) {
        this.id = UserIdsGenerator.getInstance().generateId();
        this.name = name;
        setBalancse(balance);
        this.transactionsList = new TransactionsLinkedList();
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public void setBalancse(int balance) {
        if (balance < 0)
            this.balance = 0;
        else
            this.balance = balance;
    }

    public int getBalance() {
        return this.balance;
    }

    public void addTransaction(Transaction tran) {
        this.transactionsList.addTransaction(tran);
    }

    public TransactionsList getTransactions() {
        return this.transactionsList;
    }

}